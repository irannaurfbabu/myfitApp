import { Injectable } from '@angular/core';
// import {ToastService} from '../../assets/mdb/pro/alerts';


@Injectable()
export class MeGymToastNotificationService {

  constructor(
    // private toastService: ToastService
  ) { }

  // selectRequiredFields(){
  //   this.toastService.warning("Please Fill the Required fields")
  // }

}
