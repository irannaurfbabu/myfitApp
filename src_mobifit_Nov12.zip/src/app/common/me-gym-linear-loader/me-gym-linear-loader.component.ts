import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-me-gym-linear-loader',
  templateUrl: './me-gym-linear-loader.component.html',
  styleUrls: ['./me-gym-linear-loader.component.scss']
})
export class MeGymLinearLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
