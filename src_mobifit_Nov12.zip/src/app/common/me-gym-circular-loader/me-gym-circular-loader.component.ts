import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-me-gym-circular-loader',
  templateUrl: './me-gym-circular-loader.component.html',
  styleUrls: ['./me-gym-circular-loader.component.scss']
})
export class MeGymCircularLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
